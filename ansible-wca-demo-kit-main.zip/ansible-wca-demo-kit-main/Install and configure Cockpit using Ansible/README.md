## This Playbook installs Cockpit, copies a custom configuration file, and starts the cockpit service.

The demo illustrates:
- How Ansible Lightspeed uses the full Playbook context when generating a task.
- Uses a generic task prompt to generate applicable, accurate Ansible code based on the existing Playbook content.

_Thanks to Craig Brandt for the example._
_Link to main github repo:_ https://github.com/craig-br/lightspeed-demos/tree/main/playbooks/infra/install_cockpit