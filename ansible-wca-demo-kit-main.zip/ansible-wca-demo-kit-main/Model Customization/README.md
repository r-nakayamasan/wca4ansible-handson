### Sample Training .jsonl

#### Use these .jsonl files for Tuning Demos on WCA Tuning Studio

These `.jsonl` files have been created using Ansible Content Parser tool with `ansible-linting` turned off. 

File descriptions:
1. `OpenShift_Training_Dataset_ftdata.jsonl`: Useful to demo 'Create Openshit cluster' example. Use this training data to tune a custom model which focusses on `ibm.cloudcollection`